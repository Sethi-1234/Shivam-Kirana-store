const products=[
{name:"Fresh Tomatoes",price:40,unit:"1 kg",emoji:"🍅"},
{name:"Potatoes",price:35,unit:"1 kg",emoji:"🥔"},
{name:"Full Cream Milk",price:65,unit:"1 litre",emoji:"🥛"},
{name:"Paneer",price:95,unit:"200 g",emoji:"🧀"},
{name:"Wheat Atta",price:240,unit:"5 kg",emoji:"🌾"},
{name:"Basmati Rice",price:320,unit:"5 kg",emoji:"🍚"},
{name:"Cooking Oil",price:145,unit:"1 litre",emoji:"🫙"},
{name:"Biscuits",price:30,unit:"Pack",emoji:"🍪"}];
let cart=[];
const productBox=document.getElementById("products");
productBox.innerHTML=products.map((p,i)=>`<article class="product"><div class="product-img">${p.emoji}</div><div class="product-body"><h3>${p.name}</h3><small>${p.unit}</small><div class="price">₹${p.price}</div><button class="btn add" onclick="addToCart(${i})">Add to cart</button></div></article>`).join("");
function addToCart(i){cart.push(products[i]);document.getElementById("cartCount").textContent=cart.length;renderCart()}
function renderCart(){const box=document.getElementById("cartItems");if(!cart.length){box.innerHTML="<p>Your cart is empty.</p>";document.getElementById("cartTotal").textContent="Total: ₹0";return}box.innerHTML=cart.map((p,i)=>`<div class="cart-row"><span>${p.emoji} ${p.name}</span><b>₹${p.price}</b></div>`).join("");document.getElementById("cartTotal").textContent="Total: ₹"+cart.reduce((s,p)=>s+p.price,0)}
function showCart(){document.getElementById("cartModal").classList.toggle("open");renderCart()}
function checkout(){if(!cart.length){alert("Your cart is empty.");return}alert("Order request received! Connect this button to WhatsApp, Shopify or your order system to accept live orders.")}
function toggleMenu(){document.querySelector(".nav").classList.toggle("menu-open")}
renderCart();